package com.dropchat

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Notification
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketAddress
import java.util.Collections
import java.util.UUID

// ---- tiny wire helpers: strings are sent as <int length><utf8 bytes> ----

private fun DataOutputStream.writeStr(s: String) {
    val b = s.toByteArray(Charsets.UTF_8)
    writeInt(b.size)
    write(b)
}

private fun DataInputStream.readStr(max: Int = 1_000_000): String {
    val n = readInt()
    if (n < 0 || n > max) throw IOException("bad string length")
    val b = ByteArray(n)
    readFully(b)
    return String(b, Charsets.UTF_8)
}

/**
 * Everything that is not UI lives here: discovery, the TCP server, sending, receiving,
 * chat history. The UI only observes the StateFlows below.
 *
 * Protocol (TCP, one connection per message):
 *   byte type: 0 = hello, 1 = text, 2 = file
 *   hello: server replies  id, name, port
 *   text : sender(id, name, port), text                -> server replies byte 1
 *   file : sender(id, name, port), fileName, size, raw -> server replies byte 1
 * Discovery (UDP broadcast every 3 s): "DROPCHAT1|id|name|port"
 */
object Hub {
    const val CH_SERVICE = "dropchat_service"
    const val CH_MSG = "dropchat_messages"

    private const val T_HELLO = 0
    private const val T_TEXT = 1
    private const val T_FILE = 2
    private const val PEER_TTL_MS = 12_000L

    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences

    /** Set by MainActivity so we only post notifications while the app is in the background. */
    @Volatile
    var appVisible = false

    lateinit var myId: String
        private set

    @Volatile
    var myName: String = "Android"
        private set

    @Volatile
    private var tcpPort = TCP_PORT

    private var job = SupervisorJob()
    private var scope = CoroutineScope(job + Dispatchers.IO)
    private val persistScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val persistLock = Any()
    private var started = false
    private var server: ServerSocket? = null
    private var beaconSocket: DatagramSocket? = null

    private val _peers = MutableStateFlow<Map<String, Peer>>(emptyMap())
    val peers: StateFlow<Map<String, Peer>> = _peers

    private val _messages = MutableStateFlow<Map<String, List<Message>>>(emptyMap())
    val messages: StateFlow<Map<String, List<Message>>> = _messages

    private val _myAddresses = MutableStateFlow<List<String>>(emptyList())
    val myAddresses: StateFlow<List<String>> = _myAddresses

    // ------------------------------------------------------------------ lifecycle

    @Synchronized
    fun start(context: Context) {
        if (started) return
        started = true
        app = context.applicationContext
        prefs = app.getSharedPreferences("dropchat", Context.MODE_PRIVATE)

        if (!::myId.isInitialized) {
            myId = prefs.getString("id", null)
                ?: UUID.randomUUID().toString().replace("-", "").take(12).also {
                    prefs.edit().putString("id", it).apply()
                }
            myName = prefs.getString("name", null) ?: (Build.MODEL ?: "Android")
            loadHistory()
        }
        ensureChannels(app)

        job = SupervisorJob()
        scope = CoroutineScope(job + Dispatchers.IO)
        scope.launch { runServer() }
        scope.launch { runBeaconListener() }
        scope.launch { runBeaconSender() }
        scope.launch { runPresenceTicker() }
    }

    @Synchronized
    fun stop() {
        if (!started) return
        started = false
        runCatching { server?.close() }
        runCatching { beaconSocket?.close() }
        job.cancel()
    }

    fun rename(newName: String) {
        val n = newName.trim().take(40)
        if (n.isEmpty()) return
        myName = n
        prefs.edit().putString("name", n).apply()
    }

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Background service", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_MSG, "Messages and files", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    // ------------------------------------------------------------------ TCP server

    private fun runServer() {
        val ss = try {
            ServerSocket(TCP_PORT)
        } catch (e: IOException) {
            ServerSocket(0)
        }
        server = ss
        tcpPort = ss.localPort
        try {
            while (true) {
                val s = ss.accept()
                scope.launch { handleConnection(s) }
            }
        } catch (e: IOException) {
            // server socket closed by stop()
        } finally {
            runCatching { ss.close() }
        }
    }

    private class Sender(val id: String, val name: String, val port: Int)

    private fun readSender(i: DataInputStream) = Sender(i.readStr(100), i.readStr(200), i.readInt())

    private fun writeSender(o: DataOutputStream) {
        o.writeStr(myId)
        o.writeStr(myName)
        o.writeInt(tcpPort)
    }

    private fun handleConnection(sock: Socket) {
        sock.use { s ->
            try {
                s.soTimeout = 30_000
                val input = DataInputStream(BufferedInputStream(s.getInputStream(), 64 * 1024))
                val out = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
                when (input.readByte().toInt()) {
                    T_HELLO -> {
                        out.writeStr(myId)
                        out.writeStr(myName)
                        out.writeInt(tcpPort)
                        out.flush()
                    }
                    T_TEXT -> {
                        val snd = readSender(input)
                        val text = input.readStr(2_000_000)
                        if (snd.id == myId) return
                        touchPeer(snd.id, snd.name, s.inetAddress, snd.port)
                        addMessage(
                            Message(UUID.randomUUID().toString(), snd.id, false, Kind.TEXT, text = text)
                        )
                        out.writeByte(1)
                        out.flush()
                        notifyIncoming(snd.name, text)
                    }
                    T_FILE -> receiveFile(s, input, out)
                }
            } catch (e: Exception) {
                // connection dropped; nothing to clean up here
            }
        }
    }

    private fun receiveFile(s: Socket, input: DataInputStream, out: DataOutputStream) {
        val snd = readSender(input)
        val fileName = sanitize(input.readStr(1000))
        val size = input.readLong()
        if (snd.id == myId || size < 0) return
        touchPeer(snd.id, snd.name, s.inetAddress, snd.port)

        val msgId = UUID.randomUUID().toString()
        addMessage(
            Message(msgId, snd.id, false, Kind.FILE, text = fileName, size = size, status = Status.RECEIVING)
        )

        val resolver = app.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, mimeOf(fileName))
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DropChat")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            updateMessage(snd.id, msgId) { it.copy(status = Status.FAILED) }
            persist()
            return
        }
        try {
            val os = resolver.openOutputStream(uri) ?: throw IOException("cannot open output")
            os.use { fo ->
                copyWithProgress(input, fo, size) { p ->
                    updateMessage(snd.id, msgId) { it.copy(progress = p) }
                }
            }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            updateMessage(snd.id, msgId) {
                it.copy(status = Status.DONE, progress = 1f, uri = uri.toString())
            }
            out.writeByte(1)
            out.flush()
            notifyIncoming(snd.name, "Sent you " + fileName)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            updateMessage(snd.id, msgId) { it.copy(status = Status.FAILED) }
        }
        persist()
    }

    // ------------------------------------------------------------------ sending

    fun sendText(peerId: String, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val msg = Message(
            UUID.randomUUID().toString(), peerId, true, Kind.TEXT, text = t, status = Status.SENDING
        )
        addMessage(msg)
        scope.launch { deliver(msg) }
    }

    fun sendFiles(peerId: String, uris: List<Uri>) {
        val msgs = uris.map { u ->
            val (name, size) = queryMeta(u)
            Message(
                UUID.randomUUID().toString(), peerId, true, Kind.FILE,
                text = name, size = size, uri = u.toString(), status = Status.SENDING
            ).also { addMessage(it) }
        }
        // one after another, so a big batch doesn't open dozens of connections at once
        scope.launch { for (m in msgs) deliver(m) }
    }

    fun retry(m: Message) {
        if (!m.outgoing || m.status != Status.FAILED) return
        updateMessage(m.peerId, m.id) { it.copy(status = Status.SENDING, progress = 0f) }
        scope.launch { deliver(m.copy(status = Status.SENDING, progress = 0f)) }
    }

    private fun deliver(msg: Message) {
        val peer = _peers.value[msg.peerId]
        val host = peer?.host
        if (peer == null || host == null) {
            updateMessage(msg.peerId, msg.id) { it.copy(status = Status.FAILED) }
            persist()
            return
        }
        try {
            if (msg.kind == Kind.FILE && msg.size < 0) throw IOException("unknown file size")
            Socket().use { s ->
                s.connect(InetSocketAddress(host, peer.port), 5000)
                s.soTimeout = 30_000
                val out = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 64 * 1024))
                val inp = DataInputStream(s.getInputStream())
                if (msg.kind == Kind.TEXT) {
                    out.writeByte(T_TEXT)
                    writeSender(out)
                    out.writeStr(msg.text)
                    out.flush()
                } else {
                    out.writeByte(T_FILE)
                    writeSender(out)
                    out.writeStr(msg.text)
                    out.writeLong(msg.size)
                    val src = app.contentResolver.openInputStream(Uri.parse(msg.uri))
                        ?: throw IOException("cannot open file")
                    src.use { fi ->
                        copyWithProgress(fi, out, msg.size) { p ->
                            updateMessage(msg.peerId, msg.id) { it.copy(progress = p) }
                        }
                    }
                    out.flush()
                }
                if (inp.readByte().toInt() != 1) throw IOException("no acknowledgement")
            }
            updateMessage(msg.peerId, msg.id) { it.copy(status = Status.DONE, progress = 1f) }
        } catch (e: Exception) {
            updateMessage(msg.peerId, msg.id) { it.copy(status = Status.FAILED) }
        }
        persist()
    }

    /** Copies exactly [size] bytes, reporting progress about 10 times a second. */
    private fun copyWithProgress(src: InputStream, dst: OutputStream, size: Long, onProgress: (Float) -> Unit) {
        val buf = ByteArray(64 * 1024)
        var done = 0L
        var lastTick = 0L
        while (done < size) {
            val want = minOf(buf.size.toLong(), size - done).toInt()
            val n = src.read(buf, 0, want)
            if (n < 0) throw EOFException()
            dst.write(buf, 0, n)
            done += n
            val now = System.nanoTime()
            if (now - lastTick > 100_000_000L) {
                lastTick = now
                onProgress(done.toFloat() / size.toFloat())
            }
        }
        dst.flush()
    }

    // ------------------------------------------------------------------ add device by IP

    /** Fallback when broadcasts are blocked: ask the device at [ip] who it is. */
    suspend fun addByIp(ip: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val addr = InetAddress.getByName(ip.trim())
            var added = false
            Socket().use { s ->
                s.connect(InetSocketAddress(addr, TCP_PORT), 4000)
                s.soTimeout = 5000
                val out = DataOutputStream(s.getOutputStream())
                val inp = DataInputStream(s.getInputStream())
                out.writeByte(T_HELLO)
                out.flush()
                val id = inp.readStr(100)
                val name = inp.readStr(200)
                val port = inp.readInt()
                if (id != myId) {
                    touchPeer(id, name, addr, port, sticky = true)
                    added = true
                }
            }
            added
        } catch (e: Exception) {
            false
        }
    }

    // ------------------------------------------------------------------ discovery

    private fun interfaces(): List<NetworkInterface> = try {
        NetworkInterface.getNetworkInterfaces()?.let { Collections.list(it) } ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    private fun usable(ni: NetworkInterface) =
        runCatching { ni.isUp && !ni.isLoopback }.getOrDefault(false)

    private fun broadcastAddresses(): List<InetAddress> {
        val out = linkedSetOf<InetAddress>()
        for (ni in interfaces()) {
            if (!usable(ni)) continue
            for (ia in ni.interfaceAddresses) ia.broadcast?.let { out.add(it) }
        }
        runCatching { out.add(InetAddress.getByName("255.255.255.255")) }
        return out.toList()
    }

    private fun localAddresses(): List<String> =
        interfaces().filter { usable(it) }.flatMap { ni ->
            Collections.list(ni.inetAddresses)
                .filterIsInstance<Inet4Address>()
                .filter { it.isSiteLocalAddress }
                .mapNotNull { it.hostAddress }
        }.distinct()

    private suspend fun runBeaconSender() {
        val sock = DatagramSocket()
        sock.broadcast = true
        try {
            delay(1000) // give the server a moment to bind so we advertise the right port
            while (true) {
                val payload = "DROPCHAT1|$myId|${myName.replace("|", " ")}|$tcpPort"
                    .toByteArray(Charsets.UTF_8)
                for (addr in broadcastAddresses()) {
                    try {
                        sock.send(DatagramPacket(payload, payload.size, addr, BEACON_PORT))
                    } catch (e: Exception) {
                        // this interface can't broadcast right now
                    }
                }
                _myAddresses.value = localAddresses()
                delay(3000)
            }
        } finally {
            sock.close()
        }
    }

    private fun runBeaconListener() {
        val wifi = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wifi.createMulticastLock("dropchat")
        lock.setReferenceCounted(false)
        lock.acquire()
        var sock: DatagramSocket? = null
        try {
            sock = DatagramSocket(null as SocketAddress?).apply {
                reuseAddress = true
                broadcast = true
                bind(InetSocketAddress(BEACON_PORT))
            }
            beaconSocket = sock
            val buf = ByteArray(512)
            while (true) {
                val p = DatagramPacket(buf, buf.size)
                sock.receive(p)
                val parts = String(p.data, 0, p.length, Charsets.UTF_8).split("|")
                if (parts.size < 4 || parts[0] != "DROPCHAT1") continue
                val port = parts[3].toIntOrNull() ?: continue
                touchPeer(parts[1], parts[2], p.address, port)
            }
        } catch (e: Exception) {
            // socket closed by stop()
        } finally {
            runCatching { sock?.close() }
            if (lock.isHeld) lock.release()
        }
    }

    private suspend fun runPresenceTicker() {
        while (true) {
            delay(2000)
            val now = System.currentTimeMillis()
            _peers.update { cur ->
                cur.mapValues { (_, p) ->
                    val on = p.sticky || now - p.lastSeen < PEER_TTL_MS
                    if (on == p.online) p else p.copy(online = on)
                }
            }
        }
    }

    private fun touchPeer(id: String, name: String, host: InetAddress?, port: Int, sticky: Boolean = false) {
        if (id == myId) return
        val before = _peers.value[id]
        val now = System.currentTimeMillis()
        _peers.update { cur ->
            val old = cur[id]
            val p = Peer(
                id = id,
                name = name,
                host = host ?: old?.host,
                port = if (host != null) port else (old?.port ?: port),
                lastSeen = now,
                sticky = sticky || old?.sticky == true,
                online = true
            )
            cur + (id to p)
        }
        if (before == null || before.name != name) persist()
    }

    // ------------------------------------------------------------------ messages + history

    private fun addMessage(m: Message) {
        _messages.update { cur -> cur + (m.peerId to (cur[m.peerId].orEmpty() + m)) }
        persist()
    }

    private fun updateMessage(peerId: String, id: String, change: (Message) -> Message) {
        _messages.update { cur ->
            val list = cur[peerId] ?: return@update cur
            cur + (peerId to list.map { if (it.id == id) change(it) else it })
        }
    }

    private fun persist() {
        persistScope.launch {
            synchronized(persistLock) {
                try {
                    val root = JSONObject()
                    val pa = JSONArray()
                    _peers.value.values.forEach {
                        pa.put(JSONObject().put("id", it.id).put("name", it.name))
                    }
                    root.put("peers", pa)
                    val ma = JSONArray()
                    _messages.value.values.flatten().forEach { m ->
                        ma.put(
                            JSONObject()
                                .put("id", m.id)
                                .put("peerId", m.peerId)
                                .put("out", m.outgoing)
                                .put("kind", m.kind.name)
                                .put("text", m.text)
                                .put("size", m.size)
                                .put("uri", m.uri ?: JSONObject.NULL)
                                .put("status", m.status.name)
                                .put("time", m.time)
                        )
                    }
                    root.put("messages", ma)
                    val tmp = File(app.filesDir, "history.json.tmp")
                    tmp.writeText(root.toString())
                    tmp.renameTo(File(app.filesDir, "history.json"))
                } catch (e: Exception) {
                    // history is best-effort
                }
            }
        }
    }

    private fun loadHistory() {
        try {
            val f = File(app.filesDir, "history.json")
            if (!f.exists()) return
            val root = JSONObject(f.readText())

            val peers = mutableMapOf<String, Peer>()
            val pa = root.getJSONArray("peers")
            for (i in 0 until pa.length()) {
                val o = pa.getJSONObject(i)
                peers[o.getString("id")] = Peer(o.getString("id"), o.getString("name"))
            }

            val msgs = mutableMapOf<String, MutableList<Message>>()
            val ma = root.getJSONArray("messages")
            for (i in 0 until ma.length()) {
                val o = ma.getJSONObject(i)
                var st = Status.valueOf(o.getString("status"))
                // anything that was mid-transfer when the app died did not finish
                if (st == Status.SENDING || st == Status.RECEIVING) st = Status.FAILED
                val m = Message(
                    id = o.getString("id"),
                    peerId = o.getString("peerId"),
                    outgoing = o.getBoolean("out"),
                    kind = Kind.valueOf(o.getString("kind")),
                    text = o.getString("text"),
                    size = o.getLong("size"),
                    uri = if (o.isNull("uri")) null else o.getString("uri"),
                    status = st,
                    progress = if (st == Status.DONE) 1f else 0f,
                    time = o.getLong("time")
                )
                msgs.getOrPut(m.peerId) { mutableListOf() }.add(m)
            }
            _peers.value = peers
            _messages.value = msgs
        } catch (e: Exception) {
            // corrupt or missing history: start fresh
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun notifyIncoming(from: String, body: String) {
        if (appVisible) return
        try {
            val nm = app.getSystemService(NotificationManager::class.java)
            val open = PendingIntent.getActivity(
                app, 0,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(app, CH_MSG)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(from)
                .setContentText(body)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(from.hashCode(), n)
        } catch (e: Exception) {
            // notifications are optional
        }
    }

    private fun queryMeta(u: Uri): Pair<String, Long> {
        var name = "file"
        var size = -1L
        try {
            app.contentResolver.query(
                u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
            if (size < 0) {
                size = app.contentResolver.openAssetFileDescriptor(u, "r")?.use { it.length } ?: -1L
            }
        } catch (e: Exception) {
            // fall through with what we have
        }
        return name to size
    }

    private fun sanitize(name: String): String {
        val cleaned = name.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().take(150)
        return cleaned.ifBlank { "file" }
    }

    fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }
}
