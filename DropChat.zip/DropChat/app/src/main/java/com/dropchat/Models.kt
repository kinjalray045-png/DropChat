package com.dropchat

import java.net.InetAddress

/** TCP port used for messages/files. Falls back to a random port if it is taken. */
const val TCP_PORT = 45454

/** UDP port used for the "I'm here" broadcasts that make devices find each other. */
const val BEACON_PORT = 45455

enum class Kind { TEXT, FILE }

enum class Status { SENDING, RECEIVING, DONE, FAILED }

data class Message(
    val id: String,
    val peerId: String,
    val outgoing: Boolean,
    val kind: Kind,
    /** Message body for TEXT, file name for FILE. */
    val text: String = "",
    val size: Long = 0,
    /** Source uri (outgoing) or saved location in Downloads (incoming). */
    val uri: String? = null,
    val status: Status = Status.DONE,
    val progress: Float = 0f,
    val time: Long = System.currentTimeMillis()
)

data class Peer(
    val id: String,
    val name: String,
    val host: InetAddress? = null,
    val port: Int = TCP_PORT,
    val lastSeen: Long = 0L,
    /** True for devices added by IP: they stay "online" because there are no broadcasts to confirm it. */
    val sticky: Boolean = false,
    val online: Boolean = false
)
