package com.dropchat

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------------- theme + root

@Composable
fun DropTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val colors = when {
        Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(primary = Color(0xFF4DB6AC))
        else -> lightColorScheme(primary = Color(0xFF00796B))
    }
    MaterialTheme(colorScheme = colors, content = content)
}

@Composable
fun DropApp() {
    var open by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = open != null) { open = null }
    val id = open
    if (id == null) {
        HomeScreen(onOpen = { open = it })
    } else {
        ChatScreen(peerId = id, onBack = { open = null })
    }
}

// ---------------------------------------------------------------------- home: device list

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    val peers by Hub.peers.collectAsState()
    val messages by Hub.messages.collectAsState()
    val addrs by Hub.myAddresses.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var showAdd by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var myName by remember { mutableStateOf(Hub.myName) }

    val rows = peers.values.sortedWith(
        compareByDescending<Peer> { it.online }
            .thenByDescending { messages[it.id]?.lastOrNull()?.time ?: 0L }
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DropChat", fontWeight = FontWeight.SemiBold) },
                actions = {
                    IconButton(onClick = { showAdd = true }) {
                        Icon(Icons.Filled.PersonAdd, contentDescription = "Add device by IP")
                    }
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text("Rename this device") },
                                onClick = {
                                    menu = false
                                    showRename = true
                                }
                            )
                        }
                    }
                }
            )
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad)) {
            item {
                Card(Modifier.fillMaxWidth().padding(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("This device", style = MaterialTheme.typography.labelMedium)
                        Text(myName, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (addrs.isEmpty()) "Not connected to Wi-Fi or a hotspot"
                            else "IP: " + addrs.joinToString(", "),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Both phones must be on the same Wi-Fi network, or one phone can share its hotspot.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            if (rows.isEmpty()) {
                item {
                    Text(
                        "Looking for nearby devices…\nOpen DropChat on another phone on this network.",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.fillMaxWidth().padding(32.dp)
                    )
                }
            }
            items(rows, key = { it.id }) { p ->
                val last = messages[p.id]?.lastOrNull()
                val who = if (last?.outgoing == true) "You: " else ""
                val preview = when {
                    last == null -> "Tap to start chatting"
                    last.kind == Kind.FILE -> who + "📎 " + last.text
                    else -> who + last.text
                }
                ListItem(
                    headlineContent = { Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text(preview, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    leadingContent = {
                        Box(
                            Modifier.size(44.dp).clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                p.name.take(1).uppercase(),
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    trailingContent = {
                        Text(
                            if (p.online) "online" else "offline",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (p.online) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline
                        )
                    },
                    modifier = Modifier.clickable { onOpen(p.id) }
                )
            }
        }
    }

    if (showAdd) {
        var ip by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Add device by IP") },
            text = {
                Column {
                    Text("Type the IP address shown on the other phone's home screen.")
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = ip,
                        onValueChange = { ip = it },
                        singleLine = true,
                        label = { Text("IP address") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = ip.isNotBlank(),
                    onClick = {
                        val target = ip.trim()
                        showAdd = false
                        scope.launch {
                            val ok = Hub.addByIp(target)
                            Toast.makeText(
                                ctx,
                                if (ok) "Device added" else "Couldn't reach that device",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                ) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
        )
    }

    if (showRename) {
        var name by remember { mutableStateOf(myName) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text("Rename this device") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text("Name other people see") }
                )
            },
            confirmButton = {
                TextButton(
                    enabled = name.isNotBlank(),
                    onClick = {
                        Hub.rename(name)
                        myName = Hub.myName
                        showRename = false
                    }
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------------- chat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(peerId: String, onBack: () -> Unit) {
    val peers by Hub.peers.collectAsState()
    val all by Hub.messages.collectAsState()
    val peer = peers[peerId]
    val list = all[peerId].orEmpty()
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) Hub.sendFiles(peerId, uris)
    }

    LaunchedEffect(list.size) {
        if (list.isNotEmpty()) listState.animateScrollToItem(list.lastIndex)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(peer?.name ?: "Unknown device", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (peer?.online == true) "online" else "not reachable right now",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (peer?.online == true) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { picker.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Filled.AttachFile, contentDescription = "Send files")
                    }
                    TextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Message") },
                        shape = RoundedCornerShape(24.dp),
                        maxLines = 4,
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            disabledIndicatorColor = Color.Transparent
                        )
                    )
                    IconButton(
                        enabled = text.isNotBlank(),
                        onClick = {
                            Hub.sendText(peerId, text)
                            text = ""
                        }
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                    }
                }
            }
        }
    ) { pad ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(list, key = { it.id }) { m ->
                Bubble(m, onOpen = { openFile(ctx, m) }, onRetry = { Hub.retry(m) })
            }
        }
    }
}

@Composable
fun Bubble(m: Message, onOpen: () -> Unit, onRetry: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val mine = m.outgoing
    val bg = if (mine) cs.primaryContainer else cs.surfaceVariant
    val fg = if (mine) cs.onPrimaryContainer else cs.onSurfaceVariant
    val failed = m.status == Status.FAILED
    val tappable = (m.kind == Kind.FILE && m.status == Status.DONE) || (mine && failed)

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = bg,
            contentColor = fg,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(
                Modifier
                    .clickable(enabled = tappable) { if (failed) onRetry() else onOpen() }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                if (m.kind == Kind.TEXT) {
                    Text(m.text)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.AutoMirrored.Filled.InsertDriveFile,
                            contentDescription = null,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f, fill = false)) {
                            Text(
                                m.text,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = FontWeight.Medium
                            )
                            Text(formatSize(m.size), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    if (m.status == Status.SENDING || m.status == Status.RECEIVING) {
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { m.progress },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    footer(m),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (failed) cs.error else fg.copy(alpha = 0.7f),
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

// ---------------------------------------------------------------------- helpers

private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

private fun footer(m: Message): String {
    val t = timeFormat.format(Date(m.time))
    val pct = (m.progress * 100).toInt()
    return when (m.status) {
        Status.SENDING -> if (m.kind == Kind.FILE) "Sending… $pct%" else "Sending…"
        Status.RECEIVING -> "Receiving… $pct%"
        Status.FAILED -> if (m.outgoing) "Failed · tap to retry · $t" else "Failed · $t"
        Status.DONE ->
            if (m.kind == Kind.FILE && !m.outgoing) "Saved in Downloads/DropChat · $t" else t
    }
}

fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    val mb = kb / 1024
    if (mb < 1024) return "%.1f MB".format(mb)
    return "%.2f GB".format(mb / 1024)
}

fun openFile(ctx: Context, m: Message) {
    val uri = m.uri ?: return
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(uri), Hub.mimeOf(m.text))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app found to open this file", Toast.LENGTH_SHORT).show()
    }
}
