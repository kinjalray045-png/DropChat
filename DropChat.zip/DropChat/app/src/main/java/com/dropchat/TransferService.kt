package com.dropchat

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.IBinder

/**
 * Keeps the app discoverable and able to receive files while it is in the background
 * or the screen is off. The actual work happens in [Hub]; this just holds the process alive.
 */
class TransferService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_QUIT) {
            Hub.stop()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        Hub.start(applicationContext)

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val quit = PendingIntent.getService(
            this, 1,
            Intent(this, TransferService::class.java).setAction(ACTION_QUIT),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, Hub.CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("DropChat is on")
            .setContentText("Visible to nearby devices on this network")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat), "Quit", quit
                ).build()
            )
            .build()

        startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        return START_NOT_STICKY
    }

    /** Android 15 limits how long a data-sync service may run; stop cleanly instead of being killed. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        Hub.stop()
        stopSelf()
    }

    companion object {
        const val ACTION_QUIT = "com.dropchat.QUIT"
        private const val NOTIF_ID = 1
    }
}
